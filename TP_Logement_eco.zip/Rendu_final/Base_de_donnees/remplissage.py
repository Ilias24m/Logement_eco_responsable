
import sqlite3
import random
from datetime import datetime, timedelta

# Connexion à la base de données
conn = sqlite3.connect('logement.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

# Génération et insertion de nouvelles mesures
def ajouter_mesures(nombre_mesures=200):
    # Récupération des id_capteur disponibles
    c.execute("SELECT id_capteur FROM Capteur_Actionneur")
    capteurs = [row['id_capteur'] for row in c.fetchall()]
    
    mesures = []
    for _ in range(nombre_mesures):
        # Choix aléatoire d'un capteur
        id_capteur = random.choice(capteurs)
        # Génération d'une valeur aléatoire pour la mesure
        valeur = round(random.uniform(0, 50), 2)  # Exemple pour température ou autres capteurs
        # Insertion de la mesure
        mesures.append((valeur, id_capteur))

    # Insertion des mesures en base
    c.executemany("INSERT INTO Mesure (valeur, id_capteur) VALUES (?, ?)", mesures)
    print(f"{nombre_mesures} mesures ajoutées")

# Génération et insertion de nouvelles factures
def ajouter_factures(nombre_factures=200):
    # Récupération des id_logement disponibles
    c.execute("SELECT id_logement FROM Logement")
    logements = [row['id_logement'] for row in c.fetchall()]
    
    types_facture = ['Eau', 'Electricité', 'Gaz', 'Téléphone', 'Internet']
    
    factures = []
    for _ in range(nombre_factures):
        # Choix aléatoire du type de facture et du logement
        type_facture = random.choice(types_facture)
        id_logement = random.choice(logements)
        
        # Génération de date aléatoire dans les 3 derniers mois
        date_facture = datetime.now() - timedelta(days=random.randint(1, 90))
        date_facture_str = date_facture.strftime('%Y-%m-%d')
        
        # Génération de valeurs aléatoires pour montant et consommation
        montant = round(random.uniform(20, 500), 2)
        valeur_consomme = round(random.uniform(50, 10000), 2) if type_facture != 'Téléphone' else 0

        # Ajout de la facture
        factures.append((type_facture, id_logement, date_facture_str, montant, valeur_consomme))
    
    # Insertion des factures en base
    c.executemany("""
        INSERT INTO Facture (type_facture, id_logement, date_facture, montant, valeur_consomee) 
        VALUES (?, ?, ?, ?, ?)
    """, factures)
    print(f"{nombre_factures} factures ajoutées")

# Appel des fonctions pour ajouter des données
ajouter_mesures()
ajouter_factures()

# Sauvegarde des changements et fermeture de la connexion
conn.commit()
conn.close()
