-- logement.sql

--  Suppression de toutes les tables si elles existent déjà

DROP TABLE IF EXISTS Logement;
DROP TABLE IF EXISTS Piece;
DROP TABLE IF EXISTS Capteur_Actionneur;
DROP TABLE IF EXISTS Type_Capteur;
DROP TABLE IF EXISTS Mesure;
DROP TABLE IF EXISTS Facture;

-- Création de la table 'Logement'
CREATE TABLE Logement (
    id_logement INTEGER PRIMARY KEY AUTOINCREMENT,
    adresse TEXT NOT NULL,
    numero TEXT,
    IP TEXT,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Création de la table 'Piece'
CREATE TABLE Piece (
    id_piece INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL,
    coordonnee_x INTEGER,
    coordonnee_y INTEGER,
    coordonnee_z INTEGER,
    id_logement INTEGER,
    FOREIGN KEY (id_logement) REFERENCES Logement(adresse)
);

-- Création de la table 'Capteur_Actionneur'
CREATE TABLE Capteur_Actionneur (
    id_capteur INTEGER PRIMARY KEY AUTOINCREMENT,
    id_type INTEGER,
    reference TEXT NOT NULL,
    id_piece INTEGER,
    port_communication TEXT,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_piece) REFERENCES Piece(nom),
    FOREIGN KEY (id_type) REFERENCES Type_Capteur(type)
);

-- Création de la table 'Type_Capteur'
CREATE TABLE Type_Capteur (
    id_type INTEGER PRIMARY KEY AUTOINCREMENT,
    type_censor TEXT NOT NULL,
    unite TEXT,
    plage_precision TEXT,
    autre TEXT
);

-- Création de la table 'Mesure'
CREATE TABLE Mesure (
    id_mesure INTEGER PRIMARY KEY AUTOINCREMENT,
    valeur REAL NOT NULL,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    id_capteur INTEGER,
    FOREIGN KEY (id_capteur) REFERENCES Capteur_Actionneur(id_capteur)
);

-- Création de la table 'Facture'
CREATE TABLE Facture (
    id_facture INTEGER PRIMARY KEY AUTOINCREMENT,
    type_facture TEXT NOT NULL,
    id_logement INTEGER,
    date_facture DATE,
    montant REAL,
    valeur_consomee REAL,
    FOREIGN KEY (id_logement) REFERENCES Logement(adresse)
);

--insertion d'un logement
INSERT INTO Logement (adresse, numero, IP) VALUES ('65 rue Philippe de Girard', '065233430', '172.20.10.4');

--insertion des 4 pièces
INSERT INTO Piece (nom, coordonnee_x, coordonnee_y, coordonnee_z, id_logement) VALUES ('Salon', 2, 0, 0, 1);
INSERT INTO Piece (nom, coordonnee_x, coordonnee_y, coordonnee_z, id_logement) VALUES ('Chambre 1', 2, 0, 1, 1);
INSERT INTO Piece (nom, coordonnee_x, coordonnee_y, coordonnee_z, id_logement) VALUES ('Cuisine', 2, 1, 0, 1);
INSERT INTO Piece (nom, coordonnee_x, coordonnee_y, coordonnee_z, id_logement) VALUES ('Salle de bain', 0, 1, 1, 1);

--insertion des de 4 types de capteurs/actionneurs
INSERT INTO Type_Capteur (type_censor, unite, plage_precision, autre) VALUES ('Temperature', '°C', '0.1', 'NULL');
INSERT INTO Type_Capteur (type_censor, unite, plage_precision, autre) VALUES ('Presence', 'bool', '0 ou 1', 'NULL');
INSERT INTO Type_Capteur (type_censor, unite, plage_precision, autre) VALUES ('Conso électrique', 'kWh', 'entre 0 et 10000', 'NULL');
INSERT INTO Type_Capteur (type_censor, unite, plage_precision, autre) VALUES ('Conso eau', 'l', 'entre 0 et 1000', 'NULL');

--insertion de 2 capteurs/actionneurs
INSERT INTO Capteur_Actionneur (id_type, reference, id_piece, port_communication) VALUES (1, 'capteur_temperature', 1, 'port1');
INSERT INTO Capteur_Actionneur (id_type, reference, id_piece, port_communication) VALUES (2, 'capteur_presence', 2, 'port2');

--insertion de 2 mesures
INSERT INTO Mesure (valeur, id_capteur) VALUES (25, 1);
INSERT INTO Mesure (valeur, id_capteur) VALUES (1, 2);

--insertion de 4 factures
INSERT INTO Facture (type_facture, id_logement, date_facture, montant, valeur_consomee) VALUES ('Eau', 1, '2024-11-01', 60, 13000);
INSERT INTO Facture (type_facture, id_logement, date_facture, montant, valeur_consomee) VALUES ('Electricité', 1, '2024-11-01', 300, 1500);
INSERT INTO Facture (type_facture, id_logement, date_facture, montant, valeur_consomee) VALUES ('Gaz', 1, '2024-11-01', 100, 100);
INSERT INTO Facture (type_facture, id_logement, date_facture, montant, valeur_consomee) VALUES ('télephonique', 1, '2024-11-01', 35, 0);


