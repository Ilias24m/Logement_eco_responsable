from typing import List
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.responses import HTMLResponse
import sqlite3
from datetime import datetime

app = FastAPI()

# Fonction pour obtenir une connexion à la base de données
def get_db_connection():
    conn = sqlite3.connect('logement.db')
    conn.row_factory = sqlite3.Row
    return conn

# Class pour chaque table de la base de données
class LogementModel(BaseModel):
    adresse: str
    numero: str = None
    IP: str

class PieceModel(BaseModel):
    nom: str
    coordonnee_x: int
    coordonnee_y: int
    coordonnee_z: int
    id_logement: int

class TypeCapteurModel(BaseModel):
    type_censor: str
    unite: str
    plage_precision: str
    autre: str = None

class CapteurActionneurModel(BaseModel):
    id_type: int
    reference: str
    id_piece: int
    port_communication: str

class MesureModel(BaseModel):
    valeur: float
    id_capteur: int

class FactureModel(BaseModel):
    type_facture: str
    id_logement: int
    date_facture: str
    montant: float
    valeur_consomee: float

# Endpoint POST pour ajouter un logement
@app.post("/logement", status_code=201)
async def ajouter_logement(logement: LogementModel):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("INSERT INTO Logement (adresse, numero, IP) VALUES (?, ?, ?)",
              (logement.adresse, logement.numero, logement.IP))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Logement added"}

# Endpoint GET pour récupérer tous les logements
@app.get("/logement", response_model=List[dict])
async def get_logements():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM Logement")
    logements = c.fetchall()
    conn.close()
    return [dict(logement) for logement in logements]

# Endpoint POST pour ajouter une pièce
@app.post("/piece", status_code=201)
async def ajouter_piece(piece: PieceModel):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("INSERT INTO Piece (nom, coordonnee_x, coordonnee_y, coordonnee_z, id_logement) VALUES (?, ?, ?, ?, ?)",
              (piece.nom, piece.coordonnee_x, piece.coordonnee_y, piece.coordonnee_z, piece.id_logement))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Piece added"}

# Endpoint GET pour récupérer toutes les pièces
@app.get("/piece", response_model=List[dict])
async def get_pieces():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM Piece")
    pieces = c.fetchall()
    conn.close()
    return [dict(piece) for piece in pieces]

# Endpoint POST pour ajouter un type de capteur
@app.post("/type_capteur", status_code=201)
async def ajouter_type_capteur(type_capteur: TypeCapteurModel):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("INSERT INTO Type_Capteur (type_censor, unite, plage_precision, autre) VALUES (?, ?, ?, ?)",
              (type_capteur.type_censor, type_capteur.unite, type_capteur.plage_precision, type_capteur.autre))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Type Capteur added"}

# Endpoint GET pour récupérer tous les types de capteurs
@app.get("/type_capteur", response_model=List[dict])
async def get_types_capteurs():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM Type_Capteur")
    types_capteurs = c.fetchall()
    conn.close()
    return [dict(type_capteur) for type_capteur in types_capteurs]

# Endpoint POST pour ajouter un capteur/actionneur
@app.post("/capteur_actionneur", status_code=201)
async def ajouter_capteur_actionneur(capteur: CapteurActionneurModel):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("INSERT INTO Capteur_Actionneur (id_type, reference, id_piece, port_communication) VALUES (?, ?, ?, ?)",
              (capteur.id_type, capteur.reference, capteur.id_piece, capteur.port_communication))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Capteur Actionneur added"}

# Endpoint GET pour récupérer tous les capteurs/actionneurs
@app.get("/capteur_actionneur", response_model=List[dict])
async def get_capteurs_actionneurs():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM Capteur_Actionneur")
    capteurs_actionneurs = c.fetchall()
    conn.close()
    return [dict(capteur_actionneur) for capteur_actionneur in capteurs_actionneurs]

# Endpoint POST pour ajouter une mesure
@app.post("/mesure", status_code=201)
async def ajouter_mesure(mesure: MesureModel):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("INSERT INTO Mesure (valeur, id_capteur) VALUES (?, ?)",
              (mesure.valeur, mesure.id_capteur))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Mesure added"}

# Endpoint GET pour récupérer toutes les mesures
@app.get("/mesure", response_model=List[dict])
async def get_mesures():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM Mesure")
    mesures = c.fetchall()
    conn.close()
    return [dict(mesure) for mesure in mesures]

# Endpoint POST pour ajouter une facture
@app.post("/facture", status_code=201)
async def ajouter_facture(facture: FactureModel):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("INSERT INTO Facture (type_facture, id_logement, date_facture, montant, valeur_consomee) VALUES (?, ?, ?, ?, ?)",
              (facture.type_facture, facture.id_logement, facture.date_facture, facture.montant, facture.valeur_consomee))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Facture added"}

# Endpoint GET pour récupérer toutes les factures
@app.get("/facture", response_model=List[dict])
async def get_factures():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM Facture")
    factures = c.fetchall()
    conn.close()
    return [dict(facture) for facture in factures]

@app.get("/facture_pie_chart", response_class=HTMLResponse)
async def facture_pie_chart():
    conn = get_db_connection()
    c = conn.cursor()
    factures = c.execute("SELECT type_facture, montant FROM Facture").fetchall()
    conn.close()

    # Vérification si aucune donnée n'est récupérée
    if not factures:
        raise HTTPException(status_code=404, detail="No factures found")

    # Construire les données pour Google Charts
    data = [["Type de Facture", "Montant"]]  # En-tête pour Google Charts
    for facture in factures:
        data.append([facture["type_facture"], float(facture["montant"])])  # Ajouter les données

    # Générer le HTML avec le graphique
    chart_html = f"""
    <html>
        <head>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
                google.charts.load('current', {{'packages':['corechart']}});  // Charger Google Charts
                google.charts.setOnLoadCallback(drawChart);  // Dessiner après chargement

                function drawChart() {{
                    var data = google.visualization.arrayToDataTable({data});  // Passer les données

                    var options = {{
                        title: 'Répartition des Factures',
                        width: 900,
                        height: 500
                    }};

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                    chart.draw(data, options);
                }}
            </script>
        </head>
        <body>
            <h1>Camembert des Factures</h1>
            <div id="piechart" style="width: 900px; height: 500px;"></div>  // Conteneur
        </body>
    </html>
    """
    return HTMLResponse(content=chart_html)
