from flask import Flask, jsonify, request, send_from_directory
import sqlite3
from flask_cors import CORS

app = Flask(__name__, static_folder='.')

CORS(app)  # Autoriser les requêtes Cross-Origin

# Route pour servir les fichiers HTML
@app.route('/<path:path>', methods=['GET'])
def serve_file(path):
    return send_from_directory('.', path)

# Connexion à la base de données
def get_db_connection():
    conn = sqlite3.connect('logement.db')
    conn.row_factory = sqlite3.Row  # Permet de retourner les résultats sous forme de dictionnaires
    return conn

# Route pour récupérer les capteurs/actionneurs
@app.route('/capteurs', methods=['GET'])
def get_capteurs():
    conn = sqlite3.connect('logement.db')
    conn.row_factory = sqlite3.Row
    capteurs = conn.execute('''
        SELECT C.id_capteur, T.type_censor, C.reference, P.nom AS piece, C.port_communication, C.date_insertion
        FROM Capteur_Actionneur C
        JOIN Type_Capteur T ON C.id_type = T.id_type
        JOIN Piece P ON C.id_piece = P.id_piece
    ''').fetchall()
    conn.close()
    return jsonify([dict(row) for row in capteurs])

# Route pour récupérer les factures
@app.route('/factures', methods=['GET'])
def get_factures():
    conn = get_db_connection()
    factures = conn.execute('''
        SELECT F.type_facture, F.date_facture, F.montant, F.valeur_consomee, L.adresse
        FROM Facture F
        JOIN Logement L ON F.id_logement = L.id_logement
    ''').fetchall()
    conn.close()
    return jsonify([dict(row) for row in factures])

# Route pour récupérer les mesures
@app.route('/mesures', methods=['GET'])
def get_mesures():
    conn = get_db_connection()
    mesures = conn.execute('''
        SELECT M.id_mesure, M.valeur, M.date_insertion, T.type_censor, P.nom AS piece
        FROM Mesure M
        JOIN Capteur_Actionneur C ON M.id_capteur = C.id_capteur
        JOIN Type_Capteur T ON C.id_type = T.id_type
        JOIN Piece P ON C.id_piece = P.id_piece
    ''').fetchall()
    conn.close()
    return jsonify([dict(row) for row in mesures])

# Route pour ajouter un nouveau capteur/actionneur
@app.route('/capteurs', methods=['POST'])
def add_capteur():
    data = request.get_json()
    id_type = data.get('id_type')
    reference = data.get('reference')
    id_piece = data.get('id_piece')
    port_communication = data.get('port_communication')

    if not id_type or not reference or not id_piece or not port_communication:
        return jsonify({'message': 'Données invalides'}), 400

    conn = get_db_connection()
    conn.execute('''
        INSERT INTO Capteur_Actionneur (id_type, reference, id_piece, port_communication, date_insertion)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
    ''', (id_type, reference, id_piece, port_communication))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Capteur ajouté avec succès'}), 201

# Route pour récupérer les économies
@app.route('/economies', methods=['GET'])
def get_economies():
    conn = get_db_connection()
    # Récupérer les données nécessaires pour le calcul des économies
    economies = conn.execute('''
        SELECT F.type_facture, 
               strftime('%Y-%m', F.date_facture) AS mois,
               AVG(F.valeur_consomee) OVER (PARTITION BY F.type_facture) AS moyenne,
               F.valeur_consomee,
               F.montant
        FROM Facture F
    ''').fetchall()
    conn.close()

    # Préparer les économies par mois et par type de facture
    result = {}
    for row in economies:
        mois = row['mois']
        type_facture = row['type_facture']
        moyenne = row['moyenne']
        consommation = row['valeur_consomee']
        economie = moyenne - consommation

        if mois not in result:
            result[mois] = {}
        result[mois][type_facture] = economie

    # Convertir en format JSON exploitable
    economies_list = [
        {"mois": mois, "type_facture": type_facture, "economie": economie}
        for mois, factures in result.items()
        for type_facture, economie in factures.items()
    ]
    return jsonify(economies_list)


if __name__ == '__main__':
    app.run(debug=True)
