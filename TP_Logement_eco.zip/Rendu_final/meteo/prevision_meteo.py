from typing import List
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from fastapi.responses import HTMLResponse, JSONResponse
import sqlite3
import requests
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import pandas as pd

app = FastAPI()

# Utilitaire : Connexion à la base de données
def connect_db():
    connection = sqlite3.connect('logement.db')
    connection.row_factory = sqlite3.Row
    return connection

# Modèles pour la base de données
class Logement(BaseModel):
    adresse: str
    numero: str = None
    IP: str

class Piece(BaseModel):
    nom: str
    x: int
    y: int
    z: int
    logement_id: int

class CapteurType(BaseModel):
    type: str
    unite: str
    plage_precision: str
    description: str = None

class Capteur(BaseModel):
    type_id: int
    reference: str
    piece_id: int
    port: str

class Mesure(BaseModel):
    valeur: float
    capteur_id: int

class Facture(BaseModel):
    categorie: str
    logement_id: int
    date: str
    montant: float
    consommation: float

# Endpoints de base pour le gestionnaire de logements
@app.post("/logement", status_code=201)
async def add_logement(logement: Logement):
    conn = connect_db()
    with conn:
        conn.execute("INSERT INTO Logement (adresse, numero, IP) VALUES (?, ?, ?)",
                     (logement.adresse, logement.numero, logement.IP))
    return {"message": "Logement ajouté avec succès"}

@app.get("/logement", response_model=List[dict])
async def get_logements():
    conn = connect_db()
    logements = conn.execute("SELECT * FROM Logement").fetchall()
    return [dict(row) for row in logements]

# Fonction pour récupérer les données météo
def get_weather_data(lat: float, lon: float):
    try:
        response = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat,
                "longitude": lon,
                "daily": ["temperature_2m_max", "temperature_2m_min", "precipitation_sum"],
                "timezone": "auto"
            }
        )
        response.raise_for_status()
        data = response.json()
        return data.get("daily", {})
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de la récupération des données météo : {e}")

# Endpoint pour afficher les prévisions météo
@app.get("/meteo/{latitude}/{longitude}/html", response_class=HTMLResponse)
async def afficher_previsions_meteo(latitude: float, longitude: float):
    weather_data = get_weather_data(latitude, longitude)

    if not weather_data:
        raise HTTPException(status_code=404, detail="Données météo non disponibles")

    # Construction du tableau HTML
    rows = ""
    for date, temp_max, temp_min, precip in zip(
        weather_data["time"],
        weather_data["temperature_2m_max"],
        weather_data["temperature_2m_min"],
        weather_data["precipitation_sum"]
    ):
        rows += f"<tr><td>{date}</td><td>{temp_max}°C</td><td>{temp_min}°C</td><td>{precip} mm</td></tr>"

    html_content = f"""
    <html>
        <head><title>Prévisions Météo</title></head>
        <body>
            <h1>Prévisions Météo sur 5 Jours</h1>
            <table border="1">
                <tr><th>Date</th><th>Temp. Max</th><th>Temp. Min</th><th>Précipitations</th></tr>
                {rows}
            </table>
        </body>
    </html>
    """
    return HTMLResponse(content=html_content)

# Endpoint pour afficher un graphique des prévisions météo
@app.get("/meteo/{latitude}/{longitude}/graph", response_class=HTMLResponse)
async def afficher_graphique_meteo(latitude: float, longitude: float):
    weather_data = get_weather_data(latitude, longitude)

    if not weather_data:
        raise HTTPException(status_code=404, detail="Données météo non disponibles")

    dates = weather_data["time"]
    temp_max = weather_data["temperature_2m_max"]
    temp_min = weather_data["temperature_2m_min"]
    precipitations = weather_data["precipitation_sum"]

    # Générer le graphique
    fig, ax1 = plt.subplots(figsize=(10, 6))

    ax1.plot(dates, temp_max, label="Température Max (°C)", color="red")
    ax1.plot(dates, temp_min, label="Température Min (°C)", color="blue")
    ax1.set_xlabel("Date")
    ax1.set_ylabel("Températures (°C)")
    ax1.tick_params(axis="x", rotation=45)

    ax2 = ax1.twinx()
    ax2.bar(dates, precipitations, label="Précipitations (mm)", color="gray", alpha=0.5)
    ax2.set_ylabel("Précipitations (mm)")

    fig.legend(loc="upper left")
    plt.tight_layout()

    # Convertir le graphique en image base64
    buffer = BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.read()).decode("utf-8")
    buffer.close()

    # Retourner le HTML avec l'image
    return f"""
    <html>
        <body>
            <h1>Graphique des Prévisions Météo</h1>
            <img src="data:image/png;base64,{image_base64}" />
        </body>
    </html>
    """
